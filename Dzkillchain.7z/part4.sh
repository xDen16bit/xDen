sudo apt-get install -y apparmor-profiles
sudo apt-get install -y nginx
sudo apt-get install -y apparmor-utils
cp -f /tmp/usr.sbin.nginx /etc/apparmor.d/usr.sbin.nginx
cp -f /tmp/nginx.conf /etc/nginx/nginx.conf
sudo aa-enforce nginx
sudo /etc/init.d/apparmor reload
sudo service nginx restart